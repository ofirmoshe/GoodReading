/**
 * "Visual Paradigm: DO NOT MODIFY THIS FILE!"
 * 
 * This is an automatic generated file. It will be regenerated every time 
 * you generate persistence class.
 * 
 * Modifying its content may cause the program not work, or your work may lost.
 */

/**
 * Licensee: Ort Braude College
 * License Type: Academic
 */
package i_book;

public interface ORMConstants extends org.orm.util.ORMBaseConstants {
	final int KEY_AUTHOR_BOOK = -1914455811;
	
	final int KEY_BOOK_AUTHOR = 1362436993;
	
	final int KEY_BOOK_FIELD = 325290052;
	
	final int KEY_BOOK_KEYWORD = -882025805;
	
	final int KEY_BOOK_SUBJECT = -1935502858;
	
	final int KEY_BOOK_USER_BOOKS = 1833456652;
	
	final int KEY_BOOK_VIEW = -266124773;
	
	final int KEY_FIELD_BOOK = -1725187282;
	
	final int KEY_FIELD_SUBJECT = 886846151;
	
	final int KEY_KEYWORD_BOOK = -1425902689;
	
	final int KEY_MEMBERSHIP_USER_MEMBERSHIPS = 1285142002;
	
	final int KEY_PAYMENTREQUEST_USER = -677287807;
	
	final int KEY_REVIEW_USERSBOOK = -1606980374;
	
	final int KEY_SUBJECT_BOOK = -1345565124;
	
	final int KEY_SUBJECT_FIELD = 1240659975;
	
	final int KEY_USER_BOOK_BOOK = 298382091;
	
	final int KEY_USER_BOOK_REVIEW = -568578310;
	
	final int KEY_USER_BOOK_USER = 298951661;
	
	final int KEY_USER_MEMBERSHIP_MEMBERSHIP = -410742165;
	
	final int KEY_USER_MEMBERSHIP_USER = -368391648;
	
	final int KEY_USER_PAYMENTREQUEST = -666998627;
	
	final int KEY_USER_USER_BOOKS = -2067422742;
	
	final int KEY_USER_USER_MEMBERSHIPS = 850625181;
	
	final int KEY_VIEWS_DATE_BOOK = 1938086921;
	
}
